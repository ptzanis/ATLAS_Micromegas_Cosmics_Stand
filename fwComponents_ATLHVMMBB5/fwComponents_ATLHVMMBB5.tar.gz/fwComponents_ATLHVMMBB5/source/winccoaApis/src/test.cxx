#include <iostream.h>

main()
{
	cout << "hello " << endl;
}