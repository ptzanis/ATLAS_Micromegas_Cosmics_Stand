/**
* Used to map one or more source object onto one or more destination objects
*/

class CbridgeDataObject{

}